#pragma once

#if !defined(ARDUINO)

unsigned long millis();
unsigned long micros();
void delay(unsigned int duration);
void delayMicroseconds(unsigned int duration);

#endif

