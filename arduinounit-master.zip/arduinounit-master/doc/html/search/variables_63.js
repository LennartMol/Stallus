var searchData=
[
  ['current',['current',['../class_test.html#ab33c60d07c2338204a0bafe40f995177',1,'Test']]]
];
