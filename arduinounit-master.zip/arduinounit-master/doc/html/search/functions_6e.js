var searchData=
[
  ['nextbyte',['nextByte',['../class_fake_stream.html#a4b37e51beae0c92064eb81c06b5076cd',1,'FakeStream']]]
];
