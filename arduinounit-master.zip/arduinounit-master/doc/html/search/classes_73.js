var searchData=
[
  ['string',['String',['../class_test_1_1_string.html',1,'Test']]]
];
